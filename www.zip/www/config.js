define( function ( require ) {

	"use strict";

	return {
		app_slug : 'cps-enewsletter',
		wp_ws_url : 'http://104.238.96.209/~newsimtms/wordpress/wp-appkit-api/cps-enewsletter',
		wp_url : 'http://104.238.96.209/~newsimtms/wordpress',
		//theme : 'cps-newsletter',
        theme : 'q-ios',
		version : '1.0',
		app_title : 'CPS e-Newsletter',
		app_platform : 'ios',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '$bh3twPo`@hdStW9pva6;i;VLByX~F{ZZJ-/a%q?pa]Fp%Qbgz!<obRboQUST}Se',
		options : {"refresh_interval":59},
		theme_settings : [],
		addons : []
	};

});
